package com.spring.main;
import java.util.ArrayList;
import com.spring.service.ElectionService;
import com.spring.model.Candidate;
import com.spring.config.ApplicationConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
public class Driver {

	public static void main(String[] args) {

	AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);

        ElectionService electionService = context.getBean(ElectionService.class);

        int totalVotes = electionService.getTotalVotes();
        int totalPolledVotes = electionService.totalpolledVotes();
        int unpolledVotes = electionService.unpolledVotes();
        

        System.out.println("College Election Report");
        //System.out.println();
        System.out.println("Total Number of Votes:" + totalVotes);
        System.out.println("Total Number of polled Votes:" + totalPolledVotes);
        System.out.println("Total Number of unpolled Votes:" + unpolledVotes);
        //System.out.println();

        Candidate candidateWithMaxVotes = electionService.candidateWithMaximumVote();
        
         ArrayList<Candidate> voteList=electionService.getVoteList();
        for(Candidate cad:voteList) {
        	 System.out.println("Candidate " + cad.getName() + " got " + cad.getNumberOfVotes() + " votes");
        }
        //System.out.println("Candidate " + candidateWithMaxVotes.getName() + " got " + candidateWithMaxVotes.getNumberOfVotes() + " votes");
        System.out.println("Election won by " + candidateWithMaxVotes.getName() + " with " + candidateWithMaxVotes.getNumberOfVotes() + " votes");

        context.close();
	  
		}

}
