package com.spring.dao;

import com.spring.model.Candidate;
import java.util.ArrayList;
import org.springframework.stereotype.Component;
 
import org.springframework.beans.factory.annotation.Autowired;
//Use appropriate annotation
@Component
public class ElectionDAO {
    
    @Autowired
	private ArrayList<Candidate> voteList;

	public Candidate candidateWithMaximumVote() {
	        Candidate candidateWithMaxVotes = null;
            int maxVotes = 0;
    for (Candidate candidate : voteList) {
        if (candidate.getNumberOfVotes() > maxVotes) {
            maxVotes = candidate.getNumberOfVotes();
            candidateWithMaxVotes = candidate;
        }
    }
    return candidateWithMaxVotes;
	}

	public int getTotalVotes() {
		return Candidate.getTotalVotes();
	}
 
	
	public int unpolledVotes() {
		int totalPolledVotes = this.totalpolledVotes();
        return this.getTotalVotes() - totalPolledVotes;
	}
	
	public int totalpolledVotes() {
		int totalVotes = 0;
        for (Candidate candidate : voteList) {
            totalVotes += candidate.getNumberOfVotes();
        }
        return totalVotes;
	}
 
		public ArrayList<Candidate> getVoteList() {
			return voteList;
		}
		
		public void setVoteList(ArrayList<Candidate> voteList) {
			this.voteList = voteList;
		}
		
}
