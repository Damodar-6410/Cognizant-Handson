package com.spring.main;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.spring.exception.InvalidGradeException;
import com.spring.service.StudentService;
import com.spring.config.ApplicationConfig;
import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {

	 AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);

        // Get the StudentService bean
        StudentService studentService = context.getBean(StudentService.class);

        // Get user inputs for student and hostel details
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter student name: ");
        String name = scanner.nextLine();

        System.out.print("Enter admission number: ");
        String admissionNo = scanner.nextLine();

        System.out.print("Enter grade: ");
        char grade = scanner.nextLine().charAt(0);

        System.out.print("Enter hostel name: ");
        String hostelName = scanner.nextLine();

        System.out.print("Enter room rent: ");
        float rent = Float.parseFloat(scanner.nextLine());

        scanner.close();

        // Calculate the fee
        try {
            float calculatedFee = studentService.calculateFee(name, admissionNo, grade, hostelName, rent);
            System.out.println("Calculated fee: Rs " + calculatedFee);
        } catch (InvalidGradeException e) {
            System.out.println("Invalid grade: " + e.getMessage());
        }

        context.close();
		
		}

}