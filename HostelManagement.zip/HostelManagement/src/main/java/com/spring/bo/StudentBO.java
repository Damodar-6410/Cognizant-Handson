package com.spring.bo;

import com.spring.model.Student;
 
//use appropriate annotation to make this class as component class
public class StudentBO {
	
	public float calculateFee(Student obj) {
		float fee=0;
		//fill the code
		return fee;
	}
	
	

}
