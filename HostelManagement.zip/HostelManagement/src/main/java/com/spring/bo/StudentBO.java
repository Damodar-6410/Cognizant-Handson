package com.spring.bo;

import com.spring.model.FeesDiscountDetails;
import com.spring.model.Student;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
 
//use appropriate annotation to make this class as component class
@Component
public class StudentBO {
	
	
    private final FeesDiscountDetails feesDiscountDetails;

    @Autowired
    public StudentBO(FeesDiscountDetails feesDiscountDetails) {
        this.feesDiscountDetails = feesDiscountDetails;
    }

    public float calculateFee(Student obj) {
        float rent = obj.getHostel().getRent();
        String grade = String.valueOf(obj.getGrade());
        float retunValue = 0;

        if (grade.equals("C") || grade.equals("F")) {
            retunValue = rent;
        } else {
            Map<String, Integer> feesDiscount = feesDiscountDetails.getFeesDiscount();
            
            int discountPercentage = feesDiscount.get(grade);
            
            retunValue = rent - (rent * discountPercentage / 100);
        }

        return retunValue;
    }
	

}