package com.spring.config;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.ComponentScan;
//Use appropriate annotation 
@Configuration
@ComponentScan(basePackages = {"com.spring.config","com.spring.bo","com.spring.exception","com.spring.main","com.spring.model","com.spring.service"})
@PropertySource("classpath:/feesDiscountDetails.properties")
public class ApplicationConfig {

	
}
