package com.spring.exception;

public class InvalidGradeException extends Exception {

	public InvalidGradeException(String msg) {

		super(msg);
	}

}