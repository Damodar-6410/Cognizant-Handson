
package com.spring.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.spring.bo.StudentBO ;
import com.spring.exception.InvalidGradeException;
import com.spring.model.Student;
import com.spring.model.Hostel;
//use appropriate annotation to make this class as component class
@Component
public class StudentService {	

	public StudentBO getStudentBOObj() {
		return studentBOObj;
	}

	public void setStudentBOObj(StudentBO studentBOObj) {
		this.studentBOObj = studentBOObj;
	}

	private StudentBO studentBOObj;

	//fill the code
	@Autowired
	public StudentService(StudentBO studentBOObj) {
		super();
		this.studentBOObj = studentBOObj;
	}

	public float calculateFee(String name,String admissionNo,char grade,String hostelName,float rent) throws InvalidGradeException{
		if (grade != 'O' && grade != 'D' && grade != 'A' && grade != 'B' && grade != 'C' && grade != 'F') {
            throw new InvalidGradeException("Invalid Grade");
        }

        Hostel hostel = new Hostel();
        hostel.setHostelName(hostelName);
        hostel.setRent(rent);

        Student student = new Student(hostel);
        student.setName(name);
        student.setAdmissionNo(admissionNo);
        student.setGrade(grade);
        return studentBOObj.calculateFee(student);
	}

}