package com.damodar.spring.SpringDataJPA5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataJpa5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
