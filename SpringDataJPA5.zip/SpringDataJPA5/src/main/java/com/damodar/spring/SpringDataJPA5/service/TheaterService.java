package com.damodar.spring.SpringDataJPA5.service;

import org.springframework.stereotype.Service;

import com.damodar.spring.SpringDataJPA5.entity.Movie;

@Service
public class TheaterService {

	public void saveMovie(Movie movie) {
		
	}
}
