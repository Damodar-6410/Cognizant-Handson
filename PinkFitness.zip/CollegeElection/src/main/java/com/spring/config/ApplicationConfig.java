package com.spring.config;
import java.util.ArrayList;
import org.springframework.context.annotation.Bean;
import com.spring.model.Candidate;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ComponentScan;
//import org.springframework.stereotype.Component;

//Use appropriate annotation

//@Component
@Configuration
@ComponentScan(basePackages = {"com.spring.config","com.spring.dao","com.spring.model","com.spring.service"})
public class ApplicationConfig {

	
	@Bean
    public ArrayList<Candidate> getVoteList() {
		ArrayList<Candidate> voteList=new ArrayList<Candidate>();
		voteList.add(new Candidate("Rahul","RA102021","BBA",110));
		voteList.add(new Candidate("Pavithra","RA222021","BSC",97));
		voteList.add(new Candidate("Jerom","RA332021","BBA",78));
		return voteList; 
    }
}
