package com.spring.bo;
import java.util.*;
import com.spring.model.FitnessFranchise;

public class FitnessBO {

	public double calculateNetProfit(FitnessFranchise franchise) {
		double expense=0;
		// fill the code
		 Map<String, Double> commonExpense = franchise.getCommonExpenses();
		 double sum = 0.0;

         for (Double value : commonExpense.values()) {
          sum += value;
          }
          expense = franchise.getTotalIncome()-(franchise.getTrainerSalary()+sum);
	      return expense;
					
	}
}

