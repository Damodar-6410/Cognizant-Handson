package com.spring.main;
import com.spring.model.FitnessFranchise;
import com.spring.service.FitnessService;
import com.spring.exception.NoProfitException;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Scanner;
public class Driver {

public static void main(String[] args) {
		
		
		 ClassPathXmlApplicationContext factory =new ClassPathXmlApplicationContext("beans.xml");
        // Get the FitnessFranchise bean from the container
        FitnessFranchise franchise = factory.getBean("fitnessFranchise", FitnessFranchise.class);
        FitnessFranchise franchise1 = factory.getBean("fitnessFranchise", FitnessFranchise.class);

        // Get the FitnessService bean from the container
        FitnessService service = factory.getBean("fitnessService", FitnessService.class);
        FitnessService service1 = factory.getBean("fitnessService", FitnessService.class);

        // Get the inputs from the user
        Scanner scanner = new Scanner(System.in);
        System.out.println("Pink Fitness Franchise 1 details");
        System.out.print("Enter the location: ");
        String location = scanner.nextLine();
        System.out.print("Enter the total income: ");
        double totalIncome = scanner.nextDouble();
        System.out.print("Enter the trainer salary: ");
        double trainerSalary = scanner.nextDouble();
        
        System.out.println("Pink Fitness Franchise 2 details");
        System.out.print("Enter the location: ");
        String location1 = scanner.next();
        System.out.print("Enter the total income: ");
        double totalIncome1 = scanner.nextDouble();
        System.out.print("Enter the trainer salary: ");
        double trainerSalary1 = scanner.nextDouble();

        franchise.setLocation(location);
        franchise.setTotalIncome(totalIncome);
        franchise.setTrainerSalary(trainerSalary);
        
         franchise1.setLocation(location1);
        franchise1.setTotalIncome(totalIncome1);
        franchise1.setTrainerSalary(trainerSalary1);

        try {
            service.calculateNetProfit(franchise);
            System.out.println("Pink Fitness at "+franchise.getLocation() +" franchise Amount is RS:"+franchise.getFranchiseAmount());
        }catch (NoProfitException e) {
            System.out.println(e.getMessage());
        }  
        
        try{
        	service1.calculateNetProfit(franchise1);
        	System.out.println("Pink Fitness at "+franchise1.getLocation() +" franchise Amount is RS:"+franchise1.getFranchiseAmount());
        }
        catch (NoProfitException e1) {
            System.out.println(e1.getMessage());
        } finally {
            scanner.close();
        }
	}

}