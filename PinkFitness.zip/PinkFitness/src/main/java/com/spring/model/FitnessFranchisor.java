package com.spring.model;

public interface FitnessFranchisor {
	  
 public void calculateFranchiseAmount(double netProfit);
 
}
